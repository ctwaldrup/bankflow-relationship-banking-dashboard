const customers = [
  {
    id: 1,
    name: "Jordan Lee",
    email: "jordan.lee@example.com",
    account: "Checking ••4821",
    balance: 2845.18,
    status: "Verified",
    transactions: [
      { id: "TX-1041", merchant: "Cloud Coffee", amount: 18.42, date: "2026-09-05", type: "Card" },
      { id: "TX-1040", merchant: "Metro Mobile", amount: 94.10, date: "2026-09-04", type: "Card" },
      { id: "TX-1038", merchant: "Payroll Deposit", amount: 1850.00, date: "2026-09-01", type: "ACH" }
    ]
  },
  {
    id: 2,
    name: "Maya Thompson",
    email: "maya.t@example.com",
    account: "Checking ••7734",
    balance: 512.64,
    status: "Verified",
    transactions: [
      { id: "TX-2027", merchant: "North Market", amount: 62.09, date: "2026-09-05", type: "Card" },
      { id: "TX-2026", merchant: "Rent Transfer", amount: 1200.00, date: "2026-09-03", type: "ACH" },
      { id: "TX-2022", merchant: "Fuel Station", amount: 48.31, date: "2026-08-31", type: "Card" }
    ]
  },
  {
    id: 3,
    name: "Ethan Brooks",
    email: "ethan.b@example.com",
    account: "Savings ••9012",
    balance: 8401.25,
    status: "Review",
    transactions: [
      { id: "TX-3102", merchant: "Transfer In", amount: 500.00, date: "2026-09-04", type: "ACH" },
      { id: "TX-3098", merchant: "Interest", amount: 8.22, date: "2026-09-01", type: "Credit" }
    ]
  },
  {
    id: 4,
    name: "Sofia Martinez",
    email: "sofia.m@example.com",
    account: "Checking ••4450",
    balance: 1376.92,
    status: "Verified",
    transactions: [
      { id: "TX-4114", merchant: "StreamPlus", amount: 15.99, date: "2026-09-05", type: "Card" },
      { id: "TX-4110", merchant: "QuickShip", amount: 76.44, date: "2026-09-03", type: "Card" },
      { id: "TX-4105", merchant: "Payroll Deposit", amount: 1620.00, date: "2026-09-01", type: "ACH" }
    ]
  }
];

let tickets = JSON.parse(localStorage.getItem("resolveTickets")) || [
  {
    id: "TK-1005",
    customerId: 1,
    issueType: "Card Transaction",
    priority: "Urgent",
    status: "Open",
    subject: "Possible duplicate charge at Cloud Coffee",
    description: "Customer reports seeing the same coffee purchase twice and wants help confirming whether one is a duplicate.",
    transactionId: "TX-1041",
    created: "2026-09-06 09:14",
    notes: ["Reviewed recent transactions. Need to verify whether one charge is still pending."]
  },
  {
    id: "TK-1004",
    customerId: 2,
    issueType: "Bank Transfer",
    priority: "High",
    status: "Pending",
    subject: "Rent transfer still processing",
    description: "Customer expected the transfer to complete yesterday and is asking for a status update.",
    transactionId: "TX-2026",
    created: "2026-09-05 16:42",
    notes: ["Confirmed transfer details and advised customer that support is reviewing processing status."]
  },
  {
    id: "TK-1003",
    customerId: 3,
    issueType: "Account Verification",
    priority: "Normal",
    status: "Open",
    subject: "Verification review assistance",
    description: "Customer is unsure why additional verification is needed and wants clarification on next steps.",
    transactionId: "",
    created: "2026-09-05 13:27",
    notes: []
  },
  {
    id: "TK-1002",
    customerId: 4,
    issueType: "Billing",
    priority: "Normal",
    status: "Resolved",
    subject: "Subscription charge question",
    description: "Customer did not recognize the StreamPlus merchant descriptor.",
    transactionId: "TX-4114",
    created: "2026-09-04 10:05",
    notes: ["Explained merchant descriptor and confirmed transaction details with customer."]
  }
];

const state = { currentView: "dashboard" };

const els = {
  pageTitle: document.getElementById("pageTitle"),
  navButtons: document.querySelectorAll(".nav-btn"),
  views: document.querySelectorAll(".view"),
  openCount: document.getElementById("openCount"),
  urgentCount: document.getElementById("urgentCount"),
  resolvedCount: document.getElementById("resolvedCount"),
  customerCount: document.getElementById("customerCount"),
  navOpenCount: document.getElementById("navOpenCount"),
  ticketTotalMini: document.getElementById("ticketTotalMini"),
  ticketOpenMini: document.getElementById("ticketOpenMini"),
  pageSubtitle: document.getElementById("pageSubtitle"),
  priorityTickets: document.getElementById("priorityTickets"),
  recentCustomers: document.getElementById("recentCustomers"),
  ticketsTable: document.getElementById("ticketsTable"),
  customersGrid: document.getElementById("customersGrid"),
  ticketSearch: document.getElementById("ticketSearch"),
  statusFilter: document.getElementById("statusFilter"),
  priorityFilter: document.getElementById("priorityFilter"),
  customerSearch: document.getElementById("customerSearch"),
  modalBackdrop: document.getElementById("modalBackdrop"),
  modalTitle: document.getElementById("modalTitle"),
  ticketForm: document.getElementById("ticketForm"),
  ticketDetail: document.getElementById("ticketDetail"),
  customerSelect: document.getElementById("customerSelect"),
  issueType: document.getElementById("issueType"),
  prioritySelect: document.getElementById("prioritySelect"),
  transactionSelect: document.getElementById("transactionSelect"),
  subjectInput: document.getElementById("subjectInput"),
  descriptionInput: document.getElementById("descriptionInput")
};

function saveTickets() {
  localStorage.setItem("resolveTickets", JSON.stringify(tickets));
}

function customerById(id) {
  return customers.find(c => c.id === Number(id));
}

function badge(value) {
  return `<span class="badge ${value.toLowerCase()}">${value}</span>`;
}

function currency(value) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(value);
}

function renderStats() {
  els.openCount.textContent = tickets.filter(t => t.status === "Open").length;
  els.urgentCount.textContent = tickets.filter(t => t.priority === "Urgent" && t.status !== "Resolved").length;
  els.resolvedCount.textContent = tickets.filter(t => t.status === "Resolved").length;
  els.customerCount.textContent = customers.length;
  const open = tickets.filter(t => t.status === "Open").length;
  if (els.navOpenCount) els.navOpenCount.textContent = open;
  if (els.ticketTotalMini) els.ticketTotalMini.textContent = tickets.length;
  if (els.ticketOpenMini) els.ticketOpenMini.textContent = open;
}

function renderDashboard() {
  const priority = [...tickets]
    .filter(t => t.status !== "Resolved")
    .sort((a, b) => ({Urgent: 0, High: 1, Normal: 2}[a.priority] - {Urgent: 0, High: 1, Normal: 2}[b.priority]))
    .slice(0, 4);

  els.priorityTickets.innerHTML = priority.map(t => {
    const c = customerById(t.customerId);
    return `<button class="ticket-item" onclick="openTicketDetail('${t.id}')">
      <div class="ticket-main">
        <strong>${t.subject}</strong>
        <span>${t.id} • ${c.name}</span>
      </div>
      <div>${badge(t.priority)}</div>
    </button>`;
  }).join("") || `<p>No open tickets.</p>`;

  els.recentCustomers.innerHTML = customers.slice(0, 4).map(c => `
    <div class="customer-item">
      <div class="customer-main">
        <strong>${c.name}</strong>
        <span>${c.account}</span>
      </div>
      <strong>${currency(c.balance)}</strong>
    </div>
  `).join("");
}

function filteredTickets() {
  const search = els.ticketSearch.value.toLowerCase().trim();
  const status = els.statusFilter.value;
  const priority = els.priorityFilter.value;
  return tickets.filter(t => {
    const c = customerById(t.customerId);
    const matchesSearch = !search || [t.id, t.subject, t.issueType, c.name, c.email].join(" ").toLowerCase().includes(search);
    const matchesStatus = status === "all" || t.status === status;
    const matchesPriority = priority === "all" || t.priority === priority;
    return matchesSearch && matchesStatus && matchesPriority;
  });
}

function renderTickets() {
  const rows = filteredTickets().map(t => {
    const c = customerById(t.customerId);
    return `<tr class="clickable" onclick="openTicketDetail('${t.id}')">
      <td><strong>${t.id}</strong></td>
      <td>${c.name}<br><span class="muted">${c.email}</span></td>
      <td>${t.subject}</td>
      <td>${badge(t.priority)}</td>
      <td>${badge(t.status)}</td>
      <td>${t.created}</td>
    </tr>`;
  }).join("");

  els.ticketsTable.innerHTML = `
    <table>
      <thead><tr><th>Ticket</th><th>Customer</th><th>Issue</th><th>Priority</th><th>Status</th><th>Created</th></tr></thead>
      <tbody>${rows || `<tr><td colspan="6">No tickets match your filters.</td></tr>`}</tbody>
    </table>`;
}

function renderCustomers() {
  const search = els.customerSearch.value.toLowerCase().trim();
  const filtered = customers.filter(c => !search || [c.name, c.email, c.account].join(" ").toLowerCase().includes(search));
  els.customersGrid.innerHTML = filtered.map(c => {
    const openTickets = tickets.filter(t => t.customerId === c.id && t.status !== "Resolved").length;
    const initials = c.name.split(" ").map(part => part[0]).join("").slice(0, 2).toUpperCase();
    return `<article class="customer-card">
      <div class="customer-card-header">
        <div class="customer-avatar">${initials}</div>
        <div><h4>${c.name}</h4><p>${c.email}</p></div>
      </div>
      <div class="account-summary">
        <div><span>Account</span><strong>${c.account}</strong></div>
        <div><span>Balance</span><strong>${currency(c.balance)}</strong></div>
        <div><span>Status</span><strong>${c.status}</strong></div>
        <div><span>Open Tickets</span><strong>${openTickets}</strong></div>
      </div>
    </article>`;
  }).join("");
}

function switchView(view) {
  state.currentView = view;
  els.navButtons.forEach(btn => btn.classList.toggle("active", btn.dataset.view === view));
  els.views.forEach(v => v.classList.remove("active-view"));
  document.getElementById(`${view}View`).classList.add("active-view");
  els.pageTitle.textContent = view.charAt(0).toUpperCase() + view.slice(1);
  const subtitles = {
    dashboard: "Monitor queue health, customer issues, and recent activity.",
    tickets: "Search, triage, document, and resolve customer support cases.",
    customers: "Review customer account context and active support volume."
  };
  if (els.pageSubtitle) els.pageSubtitle.textContent = subtitles[view];
  if (view === "tickets") renderTickets();
  if (view === "customers") renderCustomers();
}

function populateCustomers() {
  els.customerSelect.innerHTML = customers.map(c => `<option value="${c.id}">${c.name} — ${c.account}</option>`).join("");
  updateTransactionOptions();
}

function updateTransactionOptions() {
  const customer = customerById(els.customerSelect.value);
  els.transactionSelect.innerHTML = `<option value="">No transaction selected</option>` + customer.transactions.map(tx =>
    `<option value="${tx.id}">${tx.id} — ${tx.merchant} — ${currency(tx.amount)}</option>`
  ).join("");
}

function openNewTicket() {
  els.modalTitle.textContent = "Create Ticket";
  els.ticketForm.reset();
  populateCustomers();
  els.ticketForm.classList.remove("hidden");
  els.ticketDetail.classList.add("hidden");
  els.modalBackdrop.classList.remove("hidden");
}

function closeModal() {
  els.modalBackdrop.classList.add("hidden");
}

function openTicketDetail(ticketId) {
  const t = tickets.find(x => x.id === ticketId);
  const c = customerById(t.customerId);
  const relatedTx = c.transactions.find(tx => tx.id === t.transactionId);
  els.modalTitle.textContent = `${t.id} • ${t.subject}`;
  els.ticketForm.classList.add("hidden");
  els.ticketDetail.classList.remove("hidden");
  els.modalBackdrop.classList.remove("hidden");

  els.ticketDetail.innerHTML = `
    <div class="detail-card">
      <div class="detail-meta">
        <div><span>Customer</span><strong>${c.name}</strong></div>
        <div><span>Priority</span>${badge(t.priority)}</div>
        <div><span>Status</span>${badge(t.status)}</div>
      </div>
    </div>

    <div class="detail-card">
      <h4>Customer Issue</h4>
      <p><strong>${t.issueType}</strong></p>
      <p>${t.description}</p>
    </div>

    <div class="detail-card">
      <h4>Account Context</h4>
      <div class="transaction-list">
        <div class="transaction-row"><span>${c.account}</span><strong>${currency(c.balance)}</strong></div>
        ${relatedTx ? `<div class="transaction-row"><span>${relatedTx.date} • ${relatedTx.merchant} • ${relatedTx.type}</span><strong>${currency(relatedTx.amount)}</strong></div>` : `<div class="transaction-row"><span>No related transaction selected</span><strong>—</strong></div>`}
      </div>
    </div>

    <div class="detail-card">
      <h4>Internal Notes</h4>
      <div class="note-list">${t.notes.length ? t.notes.map(n => `<div class="note-row"><span>${n}</span></div>`).join("") : `<div class="note-row"><span>No internal notes yet.</span></div>`}</div>
    </div>

    <div class="detail-card detail-controls">
      <h4>Update Ticket</h4>
      <div class="control-row">
        <select id="detailStatus">
          ${["Open","Pending","Resolved"].map(v => `<option ${t.status === v ? "selected" : ""}>${v}</option>`).join("")}
        </select>
        <select id="detailPriority">
          ${["Normal","High","Urgent"].map(v => `<option ${t.priority === v ? "selected" : ""}>${v}</option>`).join("")}
        </select>
      </div>
      <textarea id="detailNote" placeholder="Add an internal investigation note..."></textarea>
      <div class="form-actions">
        <button class="secondary-btn" onclick="closeModal()">Close</button>
        <button class="primary-btn" onclick="saveTicketUpdate('${t.id}')">Save Update</button>
      </div>
    </div>`;
}

function saveTicketUpdate(ticketId) {
  const ticket = tickets.find(t => t.id === ticketId);
  ticket.status = document.getElementById("detailStatus").value;
  ticket.priority = document.getElementById("detailPriority").value;
  const note = document.getElementById("detailNote").value.trim();
  if (note) ticket.notes.push(note);
  saveTickets();
  renderAll();
  openTicketDetail(ticketId);
}

function nextTicketId() {
  const max = tickets.reduce((m, t) => Math.max(m, Number(t.id.split("-")[1])), 1000);
  return `TK-${max + 1}`;
}

els.ticketForm.addEventListener("submit", e => {
  e.preventDefault();
  const now = new Date();
  const created = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,"0")}-${String(now.getDate()).padStart(2,"0")} ${String(now.getHours()).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")}`;
  tickets.unshift({
    id: nextTicketId(),
    customerId: Number(els.customerSelect.value),
    issueType: els.issueType.value,
    priority: els.prioritySelect.value,
    status: "Open",
    subject: els.subjectInput.value.trim(),
    description: els.descriptionInput.value.trim(),
    transactionId: els.transactionSelect.value,
    created,
    notes: []
  });
  saveTickets();
  closeModal();
  renderAll();
  switchView("tickets");
});

els.navButtons.forEach(btn => btn.addEventListener("click", () => switchView(btn.dataset.view)));
document.querySelectorAll("[data-jump]").forEach(btn => btn.addEventListener("click", () => switchView(btn.dataset.jump)));
document.getElementById("newTicketBtn").addEventListener("click", openNewTicket);
document.getElementById("closeModalBtn").addEventListener("click", closeModal);
document.getElementById("cancelModalBtn").addEventListener("click", closeModal);
els.customerSelect.addEventListener("change", updateTransactionOptions);
els.ticketSearch.addEventListener("input", renderTickets);
els.statusFilter.addEventListener("change", renderTickets);
els.priorityFilter.addEventListener("change", renderTickets);
els.customerSearch.addEventListener("input", renderCustomers);
els.modalBackdrop.addEventListener("click", e => { if (e.target === els.modalBackdrop) closeModal(); });

function renderAll() {
  renderStats();
  renderDashboard();
  renderTickets();
  renderCustomers();
}

renderAll();
populateCustomers();

window.openTicketDetail = openTicketDetail;
window.saveTicketUpdate = saveTicketUpdate;
window.closeModal = closeModal;
